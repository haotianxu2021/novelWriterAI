from django.apps import AppConfig


class GptappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gptapp'
